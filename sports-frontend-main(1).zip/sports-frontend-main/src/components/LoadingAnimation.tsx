'use client';

export default function LoadingAnimation() {
  return (
    <div className="flex items-center justify-center p-4 text-gray-500">
      Loading...
    </div>
  );
}
